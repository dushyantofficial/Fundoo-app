<?php

namespace App\Notification;

use App\Firebase\Firebase;
use App\Models\User;
use App\Models\Notification as NotiModel;

class Notification
{
    public static function notify($user_id, $title, $body)
    {
        dd('notify');
        $user = User::find($user_id);
        $data = [
            'user_id' => $user->id,
            'title' => $title,
            'body' => $body
        ];
        NotiModel::create($data);
    }

    public static function notify_with_push($user_id, $title, $body)
    {
//        dd($body);
        $user = User::find($user_id);
//        $userFcm = $user->users_extend->fcm_key;

        $data = [
            'user_id' => $user->id,
            'title' => $title,
            'body' => $body
        ];
        \App\Models\Admin\Notification::create($data);
//        Firebase::send_push_notification($title, strip_tags($body));

    }
}
